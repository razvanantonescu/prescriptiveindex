dhtmlxSlider v.3.0 Standard edition build 110707

(c) DHTMLX Ltd. 